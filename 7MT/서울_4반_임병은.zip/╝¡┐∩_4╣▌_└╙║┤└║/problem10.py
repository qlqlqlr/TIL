############## 주의 ##############
# 입력을 받기위한 input 함수는 절대 사용하지 않습니다.
# 내장 함수 sum, min, max, len 함수를 사용하지 않습니다.
# 사용시 감점처리 되니 반드시 확인 바랍니다.
def find_one(matrix):
    # 여기에 코드를 작성하여 함수를 완성합니다.
    answer = []                                     # 값을 넣을 수 있도록 리스트로 만들어 둔 후 최종적으로 문제에서 제시된 반환값처럼 튜블로 바꾸어 쓸것  
    for x in sample_matrix:
        count_x = 0
        count_x += 1                                # 2중 for 문을 통해 2차원 리스트를 차례대로 탐색하여 1이 존재하는 위치를 카운트하여 좌표값으로 반환한다
        for y in x:
            count_y = 0
            count_y += 1
            if y == 1:
                answer = (count_x, count_y)

    return answer
            


# 아래 코드는 실행 확인을 위한 코드입니다.
if __name__ == '__main__':
    # 예시 코드는 수정하지 마세요.
    sample_matrix = [
      [0, 0, 0],
      [0, 1, 0],
      [0, 0, 0]
    ]
    print(find_one(sample_matrix))  # => (1, 1)
    # 여기부터 아래에 추가 테스트를 위한 코드 작성 가능합니다.
    