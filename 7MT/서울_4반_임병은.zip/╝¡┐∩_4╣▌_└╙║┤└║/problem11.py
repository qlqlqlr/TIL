############## 주의 ##############
# 입력을 받기위한 input 함수는 절대 사용하지 않습니다.
# 내장 함수 sum, min, max, len 함수를 사용하지 않습니다.
# 사용시 감점처리 되니 반드시 확인 바랍니다.
def get_row_col_maxsum(matrix):
    max_sum = 0
    for x in matrix:
        row_sum = 0
        for y in x:
            row_sum += y
        if max_sum < row_sum:
            max_sum = row_sum           # 로우섬이 더 현재 최대값 보다 크면 최대값을 대체한다

    im_list = []
    
    for x in matrix:
        count_x = 0
        count_x += 1            # 입력된 매트릭스의 행의 개수를 센다
        for z in x:
            count_z = 0         # 열의 개수를 센다
            count_z += 1

    for i in range(0, count_z):       # 0부터 열의 개수까지 차례로 
        for y in matrix:
            col_sum = 0
            col_sum += y[i]            # 리스트의 같은 열의 값을 더한다 

            if col_sum > max_sum:         # 열의 합이 최대값 보다 크다면 최대값으로 대체
                max_sum = col_sum
    
    return max_sum

    
            
            

        
    # 여기에 코드를 작성하여 함수를 완성합니다.
    


# 아래 코드는 실행 확인을 위한 코드입니다.
if __name__ == '__main__':
    # 예시 코드는 수정하지 마세요.
    example_matrix = [
        [1, 2, 3, 4],
        [5, 6, 7, 8],
        [9, 10, 11, 12],
        [13, 14, 15, 16]
    ]

    example_matrix2 = [
        [11, 5, 49, 20],
        [28, 16, 20, 33],
        [63, 17, 1, 15]
    ]
    print(get_row_col_maxsum(example_matrix))   # => ('row', 58)
    print(get_row_col_maxsum(example_matrix2))  # => ('col', 102)

    # 여기부터 아래에 추가 테스트를 위한 코드 작성 가능합니다.
    