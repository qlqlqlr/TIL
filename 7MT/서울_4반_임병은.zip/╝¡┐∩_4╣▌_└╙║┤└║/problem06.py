############## 주의 ##############
# 입력을 받기위한 input 함수는 절대 사용하지 않습니다.
# 내장 함수 sum, min, max, len 함수를 사용하지 않습니다.
# 사용시 감점처리 되니 반드시 확인 바랍니다.
def caesar(word, num):
    # 여기에 코드를 작성하여 함수를 완성합니다.
    answer = ''                           # 반환할 문자열 선언
    for alp in word:
        chr_num = 0
        chr_num = ord(alp) + num                 # 문자열을 순회 하면서 알파벳을 아스키 코드값으로 바꾸어 우측으로 얼마나 밀지 num 만큼 더한다
        
        if chr_num > 122:                    # 소문자와 대문자 각각 범위를 벗어났을때 다시 처음으로 돌아가도록 조건문을 만든다 
            chr_num -= 26

        elif chr_num > 90 and chr_num < 97:
            chr_num -= 26

        
        answer += chr(chr_num)             # 숫자인 아스키 코드값을 다시 그에 해당하는 문자열로 변환하여 더한다
    
    return answer


# 아래 코드는 실행 확인을 위한 코드입니다.
if __name__ == '__main__':
    # 예시 코드는 수정하지 마세요.
    print(caesar('ssafy', 1))   # => ttbgz
    print(caesar('Python', 10)) # => Zidryx
    # 여기부터 아래에 추가 테스트를 위한 코드 작성 가능합니다.
    