############## 주의 ##############
# 입력을 받기위한 input 함수는 절대 사용하지 않습니다.
# 내장 함수 sum 함수를 사용하지 않습니다.
# 사용시 감점처리 되니 반드시 확인 바랍니다.
def sum_primes(number):
    # 여기에 코드를 작성하여 함수를 완성합니다.
    answer = 0
    for num in range(2,number):           # 1보다 큰 자연수 중 약수를 찾는다. (소수의 정의를 가져옴)
        if num == 17:                     # 문제조건 : 소수 17은 합에 더하지 않고 건너뛴다.
            continue

        count = 0 
        for i in range(1, num+1):         # 해당 숫자의 약수를 찾도록 반복문을 실행하여 약수의 개수를 찾는다 
            if num % i == 0:
                count += 1
            
        if count == 2:                    # 약수가 1 그리고 자기 자신뿐이라면 count 는 2이다. 따라서 소수인 경우에만 count 가 2이다.
            answer += num                # 소수들을 모두 더해 총합을 계산한다. (17제외)
            
    return answer



# 아래 코드는 실행 확인을 위한 코드입니다.
if __name__ == '__main__':
    # 예시 코드는 수정하지 마세요.
    print(sum_primes(22)) # => 60
    print(sum_primes(33)) # => 143
    # 여기부터 아래에 추가 테스트를 위한 코드 작성 가능합니다.
    